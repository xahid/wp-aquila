/**
 * Constants.
 */

export const STORE_NAME = 'aquila_search';
