<?php
/**
 * Template for entry meta
 *
 * @package Aquila
 */

?>

<div class="entry-meta mb-3">
	<?php
	aquila_posted_on();
	aquila_posted_by();
	?>
</div>
