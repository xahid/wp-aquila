<?php
/**
 * Page template
 *
 * @package Aquila
 */

get_header();

?>

<div>Single Page</div>

<?php get_footer(); ?>
